package com.ngos.creditcard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AxessSpringbootTrainingApplicationTests {

	@Test
	void contextLoads() {
	}

}

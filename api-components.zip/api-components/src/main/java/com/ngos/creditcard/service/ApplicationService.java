package com.ngos.creditcard.service;

public interface ApplicationService {
}

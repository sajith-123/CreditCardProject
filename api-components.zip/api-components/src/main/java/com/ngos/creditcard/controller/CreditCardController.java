package com.ngos.creditcard.controller;

import com.ngos.creditcard.model.Offer;
import com.ngos.creditcard.service.OfferService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = {"http://localhost:3000"})
@RestController
@RequestMapping("/api/offers")
public class OfferController {

    @Autowired
    private OfferService offerService;

    @PostMapping("/accept/{applicationId}")
    public ResponseEntity<Offer> acceptOffer(@PathVariable String applicationId){
        return ResponseEntity.ok(offerService.acceptOffer(applicationId));
    }

    @PostMapping("/reject/{applicationId}")
    public ResponseEntity<Offer> rejectOffer(@PathVariable String applicationId){
        return ResponseEntity.ok(offerService.rejectOffer(applicationId));
    }
}

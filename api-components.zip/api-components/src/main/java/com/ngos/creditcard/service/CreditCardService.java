package com.ngos.creditcard.service;

import com.ngos.creditcard.model.Offer;

public interface OfferService {
    Offer checkOffer(String applicationId);
    Offer acceptOffer(String applicationId);
    Offer rejectOffer(String applicationId);
}

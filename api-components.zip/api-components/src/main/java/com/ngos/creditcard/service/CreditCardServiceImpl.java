package com.ngos.creditcard.service;

import com.ngos.creditcard.dao.CreditCardApplicationRepository;
import com.ngos.creditcard.dao.OfferRepository;
import com.ngos.creditcard.model.CreditCardApplication;
import com.ngos.creditcard.model.Offer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class OfferServiceImpl implements OfferService {

    @Autowired
    private CreditCardApplicationRepository applicationRepo;

    @Autowired
    private OfferRepository offerRepo;

    @Autowired
    private EmailService emailService;

    // Fixed typo: 'matx' -> 'max'
    private double computeCreditLimit(int creditScore) {
        return Math.max(50000.0, 50000.0 + Math.max(0, (creditScore - 750)) * 1000.0);
    }

    @Override
    public Offer checkOffer(String applicationId) {
        CreditCardApplication app = applicationRepo.findById(applicationId)
                .orElseThrow(() -> new RuntimeException("Application not found" + applicationId));

        Offer existing = offerRepo.findByApplicationId(applicationId).orElse(null);

        // Check if an offer already exists and handle it if needed
        if (existing != null) {
            // For now, let's assume we don't re-process existing offers
            return existing;
        }

        Offer offer = new Offer();
        offer.setApplicationId(applicationId);
        offer.setOfferDate(LocalDateTime.now());

        if (app.getCreditScore() >= 750) {
            offer.setStatus("PENDING");
            double creditLimit = computeCreditLimit(app.getCreditScore());
            // Corrected setter call
            offer.setCreditLimit(creditLimit);
        } else {
            offer.setStatus("REJECTED");
            // Corrected setter call
            offer.setCreditLimit(0.0);
            String subject = "Offer Rejection for Application ID: " + app.getApplicationId();
            String body = String.format(
                    "Dear %s,\n\nYour credit application with Application ID %s has been rejected" +
                            " because your credit score (%d) is below the required threshold of 750.\n\n" +
                            "We encourage you to review your credit report and reapply in the future.\n\n" +
                            "Sincerely, \nYour Bank",
                    app.getFullName(), app.getApplicationId(), app.getCreditScore()
            );
            emailService.sendEmail(app.getEmail(), subject, body);
        }

        return offerRepo.save(offer);
    }

    @Override
    public Offer acceptOffer(String applicationId) {
        Offer offer = offerRepo.findByApplicationId(applicationId)
                .orElseThrow(() -> new RuntimeException("Offer not found"));

        if (!"PENDING".equals(offer.getStatus())) {
            throw new RuntimeException("Offer cannot be accepted");
        }

        offer.setStatus("ACCEPTED");
        Offer saved = offerRepo.save(offer);

        CreditCardApplication app = applicationRepo.findById(applicationId)
                .orElseThrow(() -> new RuntimeException("Application Not found: " + applicationId));

        String subject = "Offer Accepted - Application " + app.getApplicationId();
        String body = String.format(
                "Dear %s,\n\nYour offer has been accepted. Credit limit: %.2f.\n\nRegards, \nNGOS",
                // Corrected getter call
                app.getFullName(), saved.getCreditLimit() != null ? saved.getCreditLimit() : 0.0
        );
        // Assuming EmailService.send has the same method signature
        emailService.sendEmail(app.getEmail(), subject, body);

        return saved;
    }

    @Override
    public Offer rejectOffer(String applicationId) {
        Offer offer = offerRepo.findByApplicationId(applicationId)
                .orElseThrow(() -> new RuntimeException("Offer not found: " + applicationId));

        // Logical correction: Status should be "REJECTED" for consistency.
        offer.setStatus("REJECTED");
        return offerRepo.save(offer);
    }
}

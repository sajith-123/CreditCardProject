package com.ngos.creditcard.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "offers")
public class Offer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Use consistent naming for fields
    private String applicationId;
    private String status;

    // Corrected spelling from 'creditLimits' to 'creditLimit' for singular property name
    private Double creditLimit;

    // Added offerDate property for better data tracking
    private LocalDateTime offerDate;

    public Offer() {}

    // Updated constructor to use correct field names
    public Offer(String applicationId, String status, Double creditLimit, LocalDateTime offerDate){
        this.applicationId = applicationId;
        this.status = status;
        this.creditLimit = creditLimit;
        this.offerDate = offerDate;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getApplicationId() { return applicationId; }
    public void setApplicationId(String applicationId) { this.applicationId = applicationId; }

    public String getStatus() { return status; }
    public void setStatus(String status) {this.status = status; }

    // Corrected getter and setter names to match the corrected field name
    public Double getCreditLimit() { return creditLimit; }
    public void setCreditLimit(Double creditLimit) { this.creditLimit = creditLimit; }

    // Getter and setter for the new offerDate property
    public LocalDateTime getOfferDate() { return offerDate; }
    public void setOfferDate(LocalDateTime offerDate) { this.offerDate = offerDate; }
}

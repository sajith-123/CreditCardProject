package com.ngos.creditcard.controller;

import com.ngos.creditcard.model.Offer;
import com.ngos.creditcard.service.OfferService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/offers")
public class OfferController {

    @Autowired
    private OfferService offerService;

    @PostMapping("/check/{applicationId}")
    public ResponseEntity<Offer> viewOffer(@PathVariable String applicationId) {
        return ResponseEntity.ok(offerService.checkOffer(applicationId));
    }

    @PostMapping("/accept/{applicationId}")
    public ResponseEntity<Offer> acceptOffer(@PathVariable String applicationId) {
        return ResponseEntity.ok(offerService.acceptOffer(applicationId));
    }

    // Add the rejectOffer endpoint, which was missing
    @PostMapping("/reject/{applicationId}")
    public ResponseEntity<Offer> rejectOffer(@PathVariable String applicationId) {
        return ResponseEntity.ok(offerService.rejectOffer(applicationId));
    }
}

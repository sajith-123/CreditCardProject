package com.ngos.creditcard.dao;

import org.springframework.stereotype.Repository;

@Repository
public interface DocumentRepository {
}

package com.ngos.creditcard.service;

import org.springframework.stereotype.Service;

@Service
public class AdminServiceImpl implements AdminService{
}

package com.ngos.creditcard.controller;

public class AdminController {
}

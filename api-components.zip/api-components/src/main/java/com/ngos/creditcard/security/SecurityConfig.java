package com.ngos.creditcard.security;

public class SecurityConfig {
}

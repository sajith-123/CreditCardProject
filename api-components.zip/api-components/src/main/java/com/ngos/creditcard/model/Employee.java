package com.ngos.creditcard.model;

public class Report {
}

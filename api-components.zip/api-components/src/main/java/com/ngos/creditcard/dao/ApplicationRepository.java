package com.ngos.creditcard.dao;

import org.springframework.stereotype.Repository;
import com.ngos.creditcard.model.CreditCardApplication;
import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface CreditCardApplicationRepository extends JpaRepository<Application, String> {

}

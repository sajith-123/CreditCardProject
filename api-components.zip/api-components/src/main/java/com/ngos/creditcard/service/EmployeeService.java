package com.ngos.creditcard.service;

public interface EmployeeService {
}

package com.ngos.creditcard.controller;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;

@RestController
@RequestMapping("/api/applicants")
public class ApplicantController {
    // Add the implementation of your applicant endpoints here
}
